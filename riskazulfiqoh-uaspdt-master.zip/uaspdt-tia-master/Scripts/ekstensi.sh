apt-get update
apt-get install -y nginx
apt-get install -y mysql